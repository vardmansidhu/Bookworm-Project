package com.bookworm.bookworm_middleware;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookwormMiddlewareApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookwormMiddlewareApplication.class, args);
	}

}
